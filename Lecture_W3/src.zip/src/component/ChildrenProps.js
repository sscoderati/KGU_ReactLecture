import React from 'react';

const ChildrenProps = (props) => {
    return (
        <>{props.children}</>
    );
};

export default ChildrenProps;