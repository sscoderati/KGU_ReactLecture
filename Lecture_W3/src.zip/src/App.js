import logo from './logo.svg';
import Hello from './component/Hello';
import BasicProps from './component/BasicProps';
import ManyProps from './component/ManyProps';
import DefaultProps from './component/DefaultProps';
import ChildrenProps from './component/ChildrenProps';
import ConditionalProps from './component/ConditionalProps';
import StateExample from './component/StateExample';

import './App.css';


function App() {
  return (
    <div>
          <Hello />
          <StateExample />
          <BasicProps name="sunghyeon" age="26" />
          <ManyProps name="sunghyeon" age="26" job="developer"/>
          <DefaultProps  />
          <ChildrenProps>
            <h1>Children 사용법</h1>
            <p>My name is sunghyeon</p>
            <p>I am 26 years old</p>
          </ChildrenProps>
          <ConditionalProps name="sunghyeon" age="26" isVip/>
    </div>
  );
}

export default App;
